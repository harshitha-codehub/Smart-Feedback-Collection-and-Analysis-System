In this read me file I,m uploading all document's drive links related to my "Smart Feedback Collection and Analysis System"
Execution Video link: https://drive.google.com/file/d/1ixsG9QexEvqCiZMeiikWeK0tNPfPzMGh/view?usp=drivesdk

Project Report link: https://drive.google.com/file/d/1aEBxX4z0cDBps8wHErks-cuvNYiArk7l/view?usp=drivesdk

Test Case Document link: https://docs.google.com/spreadsheets/d/1mJ-K9k8AWsByoNb6ES-qsQYNbE8yyRyi/edit?usp=drivesdk&ouid=116320278082193610335&rtpof=true&sd=true

Test Design Document link: https://docs.google.com/spreadsheets/d/1H2kThIOTgUu3NCA2zvCy6bWcnXbK78e3/edit?usp=drivesdk&ouid=116320278082193610335&rtpof=true&sd=true

Test Scenario Document link: https://docs.google.com/spreadsheets/d/1v57oRA1JVmx0FD9jqR3C44cYpS-jmDaf/edit?usp=drivesdk&ouid=116320278082193610335&rtpof=true&sd=true

