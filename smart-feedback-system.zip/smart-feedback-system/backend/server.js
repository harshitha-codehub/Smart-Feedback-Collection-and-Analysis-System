require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Sentiment = require('sentiment');

const User = require('./models/User');
const Feedback = require('./models/Feedback');
const auth = require('./middleware/auth');
const adminOnly = require('./middleware/admin');

const app = express();
app.use(cors());
app.use(express.json());

const sentiment = new Sentiment();

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true, useUnifiedTopology: true
}).then(() => console.log('✅ MongoDB Connected')).catch(err => console.error('DB Error', err));

// --------- Auth routes ----------

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ error: 'Email already registered' });
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);
    const user = new User({ name, email, passwordHash, role: role === 'admin' ? 'admin' : 'user' });
    await user.save();
    res.json({ message: 'User registered' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role }});
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// --------- Feedback routes ----------

// Submit feedback (guest or authenticated)
// If authenticated, attach user_id; else user_id stays null
app.post('/api/feedback', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message || message.trim().length === 0) return res.status(400).json({ error: 'Message required' });

    // sentiment
    const analysis = sentiment.analyze(message);
    const label = analysis.score > 0 ? 'Positive' : analysis.score < 0 ? 'Negative' : 'Neutral';

    // check if Authorization header provided
    let userId = null;
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;
    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        userId = decoded.id;
      } catch (err) {
        // ignore invalid token (we still accept as guest)
      }
    }

    const feedback = new Feedback({ user_id: userId, message, sentiment: label });
    await feedback.save();
    res.json({ sentiment: label, id: feedback._id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get summary counts (public)
app.get('/api/summary', async (req, res) => {
  try {
    const positive = await Feedback.countDocuments({ sentiment: 'Positive' });
    const negative = await Feedback.countDocuments({ sentiment: 'Negative' });
    const neutral = await Feedback.countDocuments({ sentiment: 'Neutral' });
    res.json({ positive, negative, neutral });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Authenticated: get own feedbacks
app.get('/api/feedback/my', auth, async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ user_id: req.user.id }).sort({ timestamp: -1 });
    res.json({ feedbacks });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin: list all feedbacks
app.get('/api/admin/feedbacks', auth, adminOnly, async (req, res) => {
  try {
    const feedbacks = await Feedback.find().populate('user_id', 'name email').sort({ timestamp: -1 });
    res.json({ feedbacks });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin: delete feedback by id
app.delete('/api/admin/feedbacks/:id', auth, adminOnly, async (req, res) => {
  try {
    await Feedback.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server listening on ${PORT}`));
