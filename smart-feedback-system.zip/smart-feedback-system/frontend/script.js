const API = 'http://localhost:5000';
const feedbackForm = document.getElementById('feedbackForm');
const resultDiv = document.getElementById('result');
const ctx = document.getElementById('sentimentChart').getContext('2d');
let chart;

const tokenKey = 'fb_token';
const userKey = 'fb_user';

document.getElementById('btnShowLogin').onclick = () => openAuthModal('login');
document.getElementById('btnShowRegister').onclick = () => openAuthModal('register');
document.getElementById('authClose').onclick = () => closeAuthModal();
document.getElementById('btnLogout').onclick = logout;
document.getElementById('authForm').addEventListener('submit', authSubmit);

function openAuthModal(mode) {
  document.getElementById('authModal').style.display = 'flex';
  document.getElementById('modalTitle').innerText = mode === 'login' ? 'Login' : 'Register';
  document.getElementById('nameField').style.display = mode === 'register' ? 'block' : 'none';

  // Show admin checkbox ONLY in register mode
  document.getElementById('adminCheckboxLabel').style.display = mode === 'register' ? 'block' : 'none';

  document.getElementById('authForm').dataset.mode = mode;
}

function closeAuthModal(){
  document.getElementById('authModal').style.display = 'none';
}

async function authSubmit(e){
  e.preventDefault();
  const mode = e.target.dataset.mode;
  const name = document.getElementById('nameField').value.trim();
  const email = document.getElementById('emailField').value.trim();
  const password = document.getElementById('passwordField').value;
  const isAdmin = document.getElementById('roleAdmin').checked;

  if(mode === 'register'){
    const res = await fetch(API + '/api/auth/register',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ name, email, password, role: isAdmin ? 'admin' : 'user' })
    });
    const j = await res.json();
    alert(j.message || j.error);
    if(res.ok) closeAuthModal();
  } else {
    const res = await fetch(API + '/api/auth/login',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ email, password })
    });
    const j = await res.json();
    if(res.ok){
      localStorage.setItem(tokenKey, j.token);
      localStorage.setItem(userKey, JSON.stringify(j.user));
      updateAuthUI();
      closeAuthModal();
      loadUserHistory();
    } else {
      alert(j.error || 'Login failed');
    }
  }
}

function updateAuthUI(){
  const token = localStorage.getItem(tokenKey);
  const user = JSON.parse(localStorage.getItem(userKey) || 'null');
  if(token && user){
    document.getElementById('btnShowLogin').style.display = 'none';
    document.getElementById('btnShowRegister').style.display = 'none';
    document.getElementById('btnLogout').style.display = 'inline-block';
    document.getElementById('userInfo').innerText = `Hello, ${user.name} (${user.role})`;
    if(user.role === 'admin') {
      const a = document.createElement('a');
      a.href = 'admin.html';
      a.innerText = 'Admin Dashboard';
      a.style.marginLeft='10px';
      document.getElementById('authActions').appendChild(a);
    }
  } else {
    document.getElementById('btnShowLogin').style.display = 'inline-block';
    document.getElementById('btnShowRegister').style.display = 'inline-block';
    document.getElementById('btnLogout').style.display = 'none';
    document.getElementById('userInfo').innerText = '';
  }
}

function logout(){
  localStorage.removeItem(tokenKey);
  localStorage.removeItem(userKey);
  location.reload();
}

// submit feedback
feedbackForm.addEventListener('submit', async e => {
  e.preventDefault();
  const message = document.getElementById('message').value.trim();
  if(!message) return;
  const token = localStorage.getItem(tokenKey);
  const res = await fetch(API + '/api/feedback', {
    method:'POST',
    headers:{ 'Content-Type':'application/json', ...(token?{Authorization:'Bearer '+token}:{}) },
    body: JSON.stringify({ message })
  });
  const j = await res.json();
  if(res.ok){
    resultDiv.innerText = `Sentiment: ${j.sentiment}`;
    resultDiv.style.color = j.sentiment === 'Positive' ? 'green' : j.sentiment === 'Negative' ? 'red' : 'gray';
    document.getElementById('message').value = '';
    loadChart();
    if(token) loadUserHistory();
  } else {
    alert(j.error || 'Error');
  }
});

// load chart
async function loadChart(){
  const res = await fetch(API + '/api/summary');
  const j = await res.json();
  if(chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Positive','Negative','Neutral'],
      datasets: [{ data: [j.positive, j.negative, j.neutral], backgroundColor:['#4caf50','#f44336','#9e9e9e'] }]
    }
  });
}

async function loadUserHistory(){
  const token = localStorage.getItem(tokenKey);
  if(!token) { document.getElementById('userHistorySection').style.display = 'none'; return; }
  const res = await fetch(API + '/api/feedback/my', { headers: { Authorization: 'Bearer ' + token }});
  const j = await res.json();
  if(res.ok){
    document.getElementById('userHistorySection').style.display = 'block';
    const ul = document.getElementById('historyList');
    ul.innerHTML = '';
    j.feedbacks.forEach(f => {
      const li = document.createElement('li');
      li.innerText = `${new Date(f.timestamp).toLocaleString()} — [${f.sentiment}] ${f.message}`;
      ul.appendChild(li);
    });
  }
}

// init
updateAuthUI();
loadChart();
loadUserHistory();
