const API = 'http://localhost:5000';
const token = localStorage.getItem('fb_token');

if(!token){
  alert('Admin must be logged in. Go to home and login as admin.');
  window.location.href = 'index.html';
}

document.getElementById('btnBack').addEventListener('click', () => window.location.href='index.html');

const tableBody = document.querySelector('#feedbackTable tbody');
const ctx = document.getElementById('adminChart').getContext('2d');
let chart;

async function loadAll(){
  const res = await fetch(API + '/api/admin/feedbacks', {
    headers: { Authorization: 'Bearer ' + token }
  });
  const j = await res.json();
  if(!res.ok){ alert(j.error || 'Error'); return; }
  tableBody.innerHTML = '';
  j.feedbacks.forEach(f => {
    const tr = document.createElement('tr');
    const user = f.user_id ? `${f.user_id.name} (${f.user_id.email})` : 'Guest';
    tr.innerHTML = `<td>${user}</td><td>${f.message}</td><td>${f.sentiment}</td><td>${new Date(f.timestamp).toLocaleString()}</td><td><button data-id="${f._id}" class="delBtn">Delete</button></td>`;
    tableBody.appendChild(tr);
  });

  document.querySelectorAll('.delBtn').forEach(b => b.onclick = async e => {
    const id = e.target.dataset.id;
    if(!confirm('Delete feedback?')) return;
    const r = await fetch(API + '/api/admin/feedbacks/' + id, { method:'DELETE', headers:{ Authorization:'Bearer ' + token }});
    const jr = await r.json();
    if(r.ok) loadAll();
    else alert(jr.error || 'Error');
  });

  // update chart
  const s = await fetch(API + '/api/summary');
  const sc = await s.json();
  if(chart) chart.destroy();
  chart = new Chart(ctx,{ type:'pie', data:{ labels:['Positive','Negative','Neutral'], datasets:[{ data:[sc.positive,sc.negative,sc.neutral], backgroundColor:['#4caf50','#f44336','#9e9e9e'] }] }});
}

loadAll();
